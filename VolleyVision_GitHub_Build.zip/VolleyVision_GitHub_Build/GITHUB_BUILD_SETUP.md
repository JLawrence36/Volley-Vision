# VolleyVision GitHub Build Setup

This project is ready for GitHub Actions + EAS Build.

## What this repo includes

- Expo React Native app source
- `eas.json` with preview and production build profiles
- GitHub Action: `.github/workflows/eas-preview-build.yml`
- GitHub Action: `.github/workflows/validate.yml`
- Android preview builds configured as APK files for easy testing

## 1. Create the GitHub repo

Create a new GitHub repository named:

```bash
VolleyVision
```

Upload/push these project files to that repo.

## 2. Install dependencies locally one time

From the project folder:

```bash
npm install
npx expo-doctor@latest
```

## 3. Log in to Expo / EAS

```bash
npx eas-cli@latest login
```

## 4. Initialize the EAS project

Run:

```bash
npx eas-cli@latest init
```

EAS will create/link the project and add `extra.eas.projectId` to `app.json`. Commit that updated file before using GitHub Actions builds.

## 5. Run one build locally first

Run Android preview first because it is the easiest test build:

```bash
npx eas-cli@latest build --platform android --profile preview
```

This lets EAS create the project, Android package setup, and credentials before GitHub tries to build non-interactively.

## 6. Create an Expo token

Create an Expo access token from your Expo account dashboard.

Then add it to GitHub:

```text
GitHub repo > Settings > Secrets and variables > Actions > New repository secret
Name: EXPO_TOKEN
Value: your Expo token
```

Never commit this token into the repo.

## 7. Trigger a GitHub build

Go to:

```text
GitHub repo > Actions > EAS Preview Build > Run workflow
```

Choose:

```text
platform: android
profile: preview
```

The GitHub Action will trigger an EAS cloud build and print the EAS build link in the workflow log.

## Notes

- Android preview produces an APK that can be installed directly on Android phones.
- iOS internal builds require Apple Developer setup and device provisioning.
- Production builds are for app store distribution later.
- Do not use GitHub for giant video uploads; the app only stores selected local video URIs in V1.
