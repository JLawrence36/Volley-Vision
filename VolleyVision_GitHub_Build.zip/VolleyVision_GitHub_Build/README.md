# VolleyVision V1

**Film in. Stats out.**

VolleyVision is a starter Expo React Native app for breaking down volleyball game film into player stats and timestamped plays.

## What works in V1

- Add/edit team roster
- Add a game and pick a volleyball video from the phone
- Watch the video inside the app
- Tap volleyball stats while watching film
- Assign each stat to a player
- Save timestamped stat events locally
- See game totals and season totals
- Jump around the video with -10, -5, +5, +10 controls
- Undo last stat event
- Clear/reset local data

## Quick local run

```bash
npm install
npx expo start
```

Scan the QR code with Expo Go.

## GitHub/EAS build setup

This version includes GitHub Actions and EAS Build configuration.

Read:

```text
GITHUB_BUILD_SETUP.md
```

Main build files:

```text
eas.json
.github/workflows/eas-preview-build.yml
.github/workflows/validate.yml
```

## GitHub Actions included

### Validate Expo App

Runs on push and pull request to `main`:

```bash
npm install
npx expo-doctor@latest
```

### EAS Preview Build

Runs manually from the GitHub Actions tab. It triggers:

```bash
npx eas-cli@latest build --platform android --profile preview --non-interactive --no-wait
```

## Important V1 note

This V1 stores data locally with AsyncStorage. The selected video URI is stored too, but a production version should copy large video files into durable app storage or upload them to cloud storage. For a fast prototype, this is fine.

## Best camera setup

- Tripod
- High and centered behind the court
- Full court visible
- Net visible
- 1080p or better
- Keep the camera still
- Clear jersey numbers
